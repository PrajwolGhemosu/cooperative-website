<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamGroup extends Model
{
    //
}
