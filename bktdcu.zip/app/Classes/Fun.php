<?php
namespace App\Classes;
use App\Setting;
use App\Group;
use App\Post;
use DB;

class Fun{
	public function team($gid){
		//dd($gid);
		$team=DB::table('teams')
            ->join('team_groups', 'teams.teamGroup', '=', 'team_groups.id')->select('teams.*')->where([['teams.status','=',1],['teams.teamGroup','=',$gid]])->get();
         //dd($team);
        return $team;
	}
}
?>