<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use auth; //newly added
use App\Setting;
use App\Slider;
use App\About;
use App\Gallery;
use App\Team;
use App\NewsNotice;
use App\Portfolio;
use DB;
use App\Members;
use App\User;
use App\Service;
use App\contact;
use App\Affiliation;
use App\Message;
use App\Download;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function login()
    {
        return view('auth.login');
    }


    public function logout()
    {
        auth::logout();
        return view('auth.login');
    }


    public function index()
    {
        $setting=Setting::find(1);
        $about=DB::table('abouts')->select('*')->where('home','=','1')->get();
        $slider=DB::table('sliders')->select('*')->where('status','=','1')->get();
        $news=DB::table('news_notices')->select('*')->where([['type','=','News'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $notice=DB::table('news_notices')->select('*')->where([['type','=','Notice'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $service=DB::table('services')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(6)->get();
        $message=DB::table('messages')->select('*')->orderBy('id','Asc')->limit(2)->get();
        $gallery=DB::table('galleries')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(9)->get();
        $portfolio=DB::table('portfolios')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(2)->get();
        $members=DB::table('members')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        //dd($aff);
        return view('front.home',['setting'=>$setting,'about'=>$about,'slider'=>$slider,'news'=>$news,'notice'=>$notice,'service'=>$service,'message'=>$message,'gallery'=>$gallery,'portfolio'=>$portfolio,'members'=>$members,'affiliation'=>$aff]);
    }

    public function newsnoticedetail($id)
    {
        $setting=Setting::find(1);
        $newsnoticedetail=DB::table('news_notices')->select('*')->where([['status','=','1'],['id','=',$id]])->orderBy('id','Desc')->get();
        $news=DB::table('news_notices')->select('*')->where([['type','=','News'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $notice=DB::table('news_notices')->select('*')->where([['type','=','Notice'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.newsnotice',['setting'=>$setting,'newsnoticedetail'=>$newsnoticedetail,'news'=>$news,'notice'=>$notice,'affiliation'=>$aff]);
    }

    public function newsall()
    {
        $setting=Setting::find(1);
        $all=DB::table('news_notices')->select('*')->where([['type','=','News'],['status','=','1']])->orderBy('id','Desc')->get();
        $side=DB::table('news_notices')->select('*')->where([['type','=','Notice'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.newsnoticeall',['setting'=>$setting,'all'=>$all,'side'=>$side,'affiliation'=>$aff]);
    }

    public function noticeall()
    {
        $setting=Setting::find(1);
        $all=DB::table('news_notices')->select('*')->where([['type','=','Notice'],['status','=','1']])->orderBy('id','Desc')->get();
        $side=DB::table('news_notices')->select('*')->where([['type','=','News'],['status','=','1']])->orderBy('id','Desc')->limit(4)->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.newsnoticeall',['setting'=>$setting,'all'=>$all,'side'=>$side,'affiliation'=>$aff]);
    }

    public function about()
    {   
        $setting=Setting::find(1);
        $about=About::all();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.about',['setting'=>$setting,'about'=>$about,'affiliation'=>$aff]);
    }

    public function members()//unfinished
    {   
        $setting=Setting::find(1);
        $members=Members::all();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.members',['setting'=>$setting,'members'=>$members,'affiliation'=>$aff]);
    }
    
    public function membersDetail($id)
    {   
        $setting=Setting::find(1);
        $members=DB::table('members')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(3)->get();
        $membersDetail=DB::table('members')->select('*')->where([['status','=','1'],['id','=',$id]])->orderBy('id','Desc')->get();
        $services=DB::table('services')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(3)->get();
        $gallery=DB::table('galleries')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(3)->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.membersDetail',['setting'=>$setting,'members'=>$members,'membersDetail'=>$membersDetail,'services'=>$services,'gallery'=>$gallery,'affiliation'=>$aff]);
    }



    public function BOD()
    {   
        $setting=Setting::find(1);
        $team=DB::table('teams')->select('*')->where([['teamGroup','=','BOD Team'],['status','=','1']])->orderBy('name','Asc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.BOD',['setting'=>$setting,'team'=>$team,'affiliation'=>$aff]);
    }

    public function managementTeam()
    {   
        $setting=Setting::find(1);
        $team=DB::table('teams')->select('*')->where([['teamGroup','=','Management Team'],['status','=','1']])->orderBy('name','Asc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.managementTeam',['setting'=>$setting,'team'=>$team,'affiliation'=>$aff]);
    }


    public function services()
    {   
        $setting=Setting::find(1);
        $services=DB::table('services')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.services',['setting'=>$setting,'services'=>$services,'affiliation'=>$aff]);
    }

    public function servicesDetail($id)
    {   
        $setting=Setting::find(1);
        $services=DB::table('services')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(3)->get();
        $servicesDetail=DB::table('services')->select('*')->where([['status','=','1'],['id','=',$id]])->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.servicesDetail',['setting'=>$setting,'services'=>$services,'servicesDetail'=>$servicesDetail,'affiliation'=>$aff]);
    }


    public function gallery()
    {   
        $setting=Setting::find(1);
        $gallery=DB::table('galleries')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.gallery',['setting'=>$setting,'gallery'=>$gallery,'affiliation'=>$aff]);
    }


    public function program()
    {   
        $setting=Setting::find(1);
        $program=DB::table('portfolios')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();

        return view('front.pages.program',['setting'=>$setting,'program'=>$program,'affiliation'=>$aff]);
    }

    public function programDetail($id)
    {   
        $setting=Setting::find(1);
        $program=DB::table('portfolios')->select('*')->where('status','=','1')->orderBy('id','Desc')->limit(3)->get();
        $programDetail=DB::table('portfolios')->select('*')->where([['status','=','1'],['id','=',$id]])->orderBy('id','Desc')->get();
        $images=DB::table('portimages')->select('*')->where([['status','=','1'],['pid','=',$id]])->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.programDetail',['setting'=>$setting,'program'=>$program,'programDetail'=>$programDetail,'images'=>$images,'affiliation'=>$aff]);
    }

    public function news()
    {
        $setting=Setting::find(1);
        $news=DB::table('news_notices')->select('*')->where([['type','=','News'],['status','=','1']])->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.news',['setting'=>$setting,'news'=>$news,'affiliation'=>$aff]);
    }


    public function notice()
    {
        $setting=Setting::find(1);
        $notice=DB::table('news_notices')->select('*')->where([['type','=','Notice'],['status','=','1']])->orderBy('id','Desc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.notice',['setting'=>$setting,'notice'=>$notice,'affiliation'=>$aff]);
    }

    public function downloads()
    {
        $setting=Setting::find(1); 
        $downloads=Download::all();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.downloads',['setting'=>$setting,'downloads'=>$downloads,'affiliation'=>$aff]);
    }

    public function contact()
    {
        $setting=Setting::find(1);
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get(); 
        
        return view('front.pages.contact',['setting'=>$setting,'affiliation'=>$aff]);
    }

    public function badloaner()
    {
        $setting=Setting::find(1); 
        $badloaner=DB::table('bad_loaners')->select('*')->orderBy('id','Asc')->get();
        $aff=DB::table('affiliations')->select('*')->where('status','=','1')->orderBy('id','Desc')->get();
        
        return view('front.pages.badloaner',['setting'=>$setting,'badloaner'=>$badloaner,'affiliation'=>$aff]);
    }

/*    public function affiliation()
    {
        $setting=Setting::find(1); 
        $aff=DB::table('affiliations')->select('*')->where(['status','=','1'])->orderBy('id','Desc')->get();
        return view('front.common.footer',['setting'=>$setting,'aff'=>$aff]);

    }*/
    


}
