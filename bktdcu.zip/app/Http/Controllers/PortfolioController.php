<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Portfolio;
use Input as Input;
use File;
use Image; 
use Auth;

class PortfolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $portfolio=new Portfolio();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/portfolio/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(981, 654);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $portfolio->file=$image;
                
        }

            else
        {
            
        
            return redirect('D-portfolio');

        }

        $portfolio->title=$request->title;
        $portfolio->description=$request->description;

        $portfolio->nepTitle=$request->nepTitle;
        $portfolio->nepDescription=$request->nepDescription;

        $portfolio->status=0;
        $portfolio->rank=1;
        $portfolio->caption=$request->caption;
        $portfolio->nepCaption=$request->nepCaption;
        $portfolio->keywords=$request->keywords;
        $portfolio->metaTag=$request->metaTag;
        $portfolio->metaDescription=$request->metaDescription;
        $portfolio->user_id=Auth::id();
        $portfolio->save();
        return redirect('D-portfolio');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $portfolio=Portfolio::paginate(9);
        $result=Portfolio::find($id);
        //dd($sl);
        return view('back.portfolio.edit',['row'=>$setting,'portfolio'=>$portfolio,'result'=>$result]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $portfolio=Portfolio::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/portfolio/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(981, 654);
            $img->save(public_path($dest_path.$filename));

            $portfolio->file = $dest_path.$filename;
            
            //$portfolio->imagefile=$image;
            
            }

            else
            {
            
            $dest_path = "img/portfolio/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(981, 654);
            $img->save(public_path($dest_path.$filename));

            $portfolio->file = $dest_path.$filename;
            
            //$portfolio->imagefile=$image;
            
            }

                
        }
        else
        {
            $portfolio->file=$request->image;

        }

        $portfolio->title=$request->title;
        $portfolio->description=$request->description;

        $portfolio->nepTitle=$request->nepTitle;
        $portfolio->nepDescription=$request->nepDescription;
        
        $portfolio->caption=$request->caption;
        $portfolio->nepCaption=$request->nepCaption;
        $portfolio->keywords=$request->keywords;
        $portfolio->metaTag=$request->metaTag;
        $portfolio->metaDescription=$request->metaDescription;
        $portfolio->user_id=Auth::id();
        $portfolio->save();
        return redirect('D-portfolio');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=Portfolio::find($id);
        if(!is_null($data->file)) //image files
        {
            $file_path=$data->file;
            if(file_exists($file_path))
                unlink($file_path);
        }

        $data->delete();
        
        return redirect('D-portfolio');

    }


public function inactivate(Request $request, $id)
    {
        $portfolio=Portfolio::find($id);
        $portfolio->user_id=Auth::id();
        $portfolio->status=1;

        $portfolio->save();
        return redirect('D-portfolio'); 
    }


    public function activate(Request $request, $id)
    {
        $portfolio=Portfolio::find($id);
        $portfolio->user_id=Auth::id();
        $portfolio->status=0;
        //dd($slider);

        $portfolio->save();
        return redirect('D-portfolio'); 
    }

}
