<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Affiliation;
use Auth;
use Input as Input;
use File;
use Image; 

class AffiliationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $affiliation=new Affiliation();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/affiliate/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(200, 200);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $affiliation->image=$image;
                
        }

            else
        {
            
        
            return redirect('affiliation');

        }


        $affiliation->imageName=$request->imageName;
        $affiliation->caption=$request->caption;
        $affiliation->keywords=$request->keywords;
        $affiliation->metaTag=$request->metaTag;
        $affiliation->metaDescription=$request->metaDescription;
        $affiliation->user_id=Auth::id();
        $affiliation->status=0;

        $affiliation->user_id=Auth::id();
        $affiliation->save();
        return redirect('affiliation');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $setting=Setting::all();
        $affiliation=Affiliation::paginate(9);
        $result=Affiliation::find($id);
        //dd($sl);
        return view('back.affiliation.edit',['row'=>$setting,'affiliation'=>$affiliation,'result'=>$result]);


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $affiliation=Affiliation::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/affiliate/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(200, 200);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $affiliation->image=$image;
            
            }

            else
            {
            
            $dest_path = "img/affiliate/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(200, 200);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $affiliation->image=$image;
            
            }

                
        }
        else
        {
            $affiliation->image=$request->image;

        }

        $affiliation->imageName=$request->imageName;
        $affiliation->caption=$request->caption;
        $affiliation->keywords=$request->keywords;
        $affiliation->metaTag=$request->metaTag;
        $affiliation->metaDescription=$request->metaDescription;
        $affiliation->user_id=Auth::id();

        $affiliation->save();
        return redirect('affiliation');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        $data=Affiliation::find($id);
        if(!is_null($data->image)) //image files
        {
            $file_path=$data->image;
            if(file_exists($file_path))
                unlink($file_path);
        }

        $data->delete();
        
        return redirect('affiliation');
    }


    public function inactivate(Request $request, $id)
    {
        $affiliation=Affiliation::find($id);
        $affiliation->user_id=Auth::id();
        $affiliation->status=1;

        $affiliation->save();
        return redirect('affiliation'); 
    }


    public function activate(Request $request, $id)
    {
        $affiliation=Affiliation::find($id);
        $affiliation->user_id=Auth::id();
        $affiliation->status=0;
        //dd($slider);

        $affiliation->save();
        return redirect('affiliation'); 
    }

}
