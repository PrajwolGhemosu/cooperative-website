<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Setting;
use App\About;
use App\Members;
use App\Slider;
use App\Gallery;
use App\Portfolio;
use App\Team;
use App\Service;
use App\Ourclients;
use App\Career;
use App\Donar;
use App\NewsNotice;
use App\UserCareer;
use App\Contact;
use App\Affiliation;
use App\Message;
use App\Download;
use App\Feedback;


class AdminController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function admin()
    {
    	$setting=setting::all();
    
        return view('back.admin',['row'=>$setting]);
    }
       
        public function slider()
    {
        $setting=Setting::all();
        $slider=Slider::paginate(9);
        //dd($sl);
        return view('back.slider.create',['row'=>$setting,'slider'=>$slider]);
    }

        public function newsnotice()
    {
        $setting=Setting::all();
        $newsnotice=NewsNotice::paginate(10);
        //dd($sl);
        return view('back.newsnotice.create',['row'=>$setting,'newsnotice'=>$newsnotice]);
    }

        public function about()
    {
        $about=About::paginate(10);
        $setting=setting::all();

        return view('back.about.index',['about'=>$about,'row'=>$setting]);
    }

    public function about_add()
    {
        $setting=setting::all();

        return view('back.about.create',['row'=>$setting]);
    }

       public function service()
    {
        $setting=Setting::all();
        $service=Service::all();
        //dd($sl);
        return view('back.service.index',['row'=>$setting,'service'=>$service]);
    }

        public function viewService()
    {
        $setting=Setting::all();
        $service=Service::paginate(10);
        
        //dd($sl);
        return view('back.service.view',['row'=>$setting,'service'=>$service]);
    }

        public function team()
    {
        $setting=Setting::all();
        $team=Team::paginate(9);
        //dd($sl);
        return view('back.team.index',['row'=>$setting,'team'=>$team]);
    }

        public function viewTeam()
    {
        $setting=Setting::all();
        $team=Team::paginate(10);
        //dd($sl);
        return view('back.team.view',['row'=>$setting,'team'=>$team]);
    }


        public function message()
    {
        $setting=Setting::all();
        $message=Message::paginate(9);
        //dd($sl);
        return view('back.message.index',['row'=>$setting,'message'=>$message]);
    }

        public function viewMessage()
    {
        $setting=Setting::all();
        $message=Message::paginate(10);
        //dd($sl);
        return view('back.message.view',['row'=>$setting,'message'=>$message]);
    }  

    public function download()
    {
        $setting=Setting::all();
        $download=Download::paginate(9);
        //dd($sl);
        return view('back.download.index',['row'=>$setting,'download'=>$download]);
    }

        public function viewDownload()
    {
        $setting=Setting::all();
        $download=Download::paginate(10);
        //dd($sl);
        return view('back.download.view',['row'=>$setting,'download'=>$download]);
    } 


    public function gallery()
    {

        $setting=setting::all();
        $gallery=Gallery::paginate(9);
        
        return view('back.gallery.create',['row'=>$setting,'gallery'=>$gallery]);
    }

    public function portfolio()
    {

        $setting=setting::all();
        $portfolio=Portfolio::paginate(9);
        
        return view('back.portfolio.create',['row'=>$setting,'portfolio'=>$portfolio]);
    }



        public function contact()
    {
        $setting=Setting::all();
        $contact=Contact::paginate(10);
        //dd($sl);
        return view('back.contact.index',['row'=>$setting,'contact'=>$contact]);
    }

        public function feedback()
    {
        $setting=Setting::all();
        $feedback=Feedback::paginate(10);
        //dd($sl);
        return view('back.feedback.index',['row'=>$setting,'feedback'=>$feedback]);
    }

         public function affiliation()
    {
        $setting=Setting::all();
        $affiliation=Affiliation::paginate(9);
        //dd($sl);
        return view('back.affiliation.index',['row'=>$setting,'affiliation'=>$affiliation]);
    }
        

        public function user()
    {
        $user=User::paginate(10);

        $setting=setting::all();
    	return view('back.user.create',['rows'=>$user,'row'=>$setting]);

    }

     
    
     public function setting()
    {
    	$setting=setting::all();
        return view('back.setting.index',['rows'=>$setting],['row'=>$setting]);
    }




    public function members()
    {
        $setting=Setting::all();
        $member=Members::all();
        return view('back.members.index',['row'=>$setting,'member'=>$member]);
    }

    public function viewMembers()
    {
        $setting=setting::all();
        $member=Members::paginate(10);

        return view('back.members.view',['row'=>$setting,'member'=>$member]);
    }

    public function portimage($id)
    {

        $setting=setting::all();
        $portfolio=Portfolio::paginate(9);
        
        return view('back.portfolio.portimage',['row'=>$setting,'portfolio'=>$portfolio,'id'=>$id]);
    }


}
