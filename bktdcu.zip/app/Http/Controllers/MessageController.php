<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use Auth;
use Input as Input;
use File;
use Image;
use App\Message;


class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $message=new Message();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/message/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(300, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $message->image=$image;
                
        }

            else
    {
        
    
        return redirect('message');

    }

        $message->name=$request->name;
        $message->position=$request->position;
        $message->title=$request->title;
        $message->message=$request->message;
        $message->nepName=$request->nepName;
        $message->nepPosition=$request->nepPosition;
        $message->nepTitle=$request->nepTitle;
        $message->nepMessage=$request->nepMessage;
        $message->save();
        return redirect('message');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $message=Message::paginate(9);
        $result=Message::find($id);

        //dd($sl);
        return view('back.message.edit',['row'=>$setting,'message'=>$message,'result'=>$result]);
  
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $message=Message::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/message/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(300, 300);
            $img->save(public_path($dest_path.$filename));

            $message->file = $dest_path.$filename;
            
            $message->image=$image;
            
            }

            else
            {
            
            $dest_path = "img/message/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(300, 300);
            $img->save(public_path($dest_path.$filename));
            $message->image = $dest_path.$filename;
                      
            }
               
        }
        else
        {
            $message->image=$request->h_image;

        }

        $message->name=$request->name;
        $message->position=$request->position;
        $message->title=$request->title;
        $message->message=$request->message;
        $message->nepName=$request->nepName;
        $message->nepPosition=$request->nepPosition;
        $message->nepTitle=$request->nepTitle;
        $message->nepMessage=$request->nepMessage;
        $message->save();
        return redirect('viewMessage');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=Message::find($id);
        if(!is_null($data->image)) //image files
        {
            $file_path=$data->image;
            if(file_exists($file_path))
                unlink($file_path);
        }
        
        $data->delete();
        return redirect('viewMessage');

    }

}
