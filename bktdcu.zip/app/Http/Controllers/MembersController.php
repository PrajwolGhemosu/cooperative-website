<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Members;
use Auth;
use App\Setting;
use Input as Input;
use File;
use Image;// for resize of image
class MembersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $member=new Members();

        $member->finance_name=$request->finance;
        $member->address=$request->address;
        $member->contactno=$request->contactno;
        $member->email=$request->email;
        $member->introduction=$request->introduction;
        $member->BOD_name=$request->bod_name;
        $member->BODM_position=$request->position;
        $member->BODM_intro=$request->introduction;
        $member->MgmtTeam_name=$request->MgmtTeam_name;
        $member->MgmtTeam_position=$request->MgmtTeam_position;
        $member->MgmtTeam_intro=$request->MgmtTeam_intro;

        $member->nepFinance_name=$request->nepFinance_name;
        $member->nepAddress=$request->nepAddress;
        $member->nepIntroduction=$request->nepIntro;
        $member->nepBOD_name=$request->nepBOD_name;
        $member->nepBODM_position=$request->nepBODM_position;
        $member->nepBODM_intro=$request->nepBODM_intro;
        $member->nepMgmtTeam_name=$request->nepMgmtTeam_name;
        $member->nepMgmtTeam_position=$request->nepMgmtTeam_position;
        $member->nepMgmtTeam_intro=$request->nepMgmtTeam_intro;


        $member->status=0;
        $member->active=0;
        $member->caption=$request->caption;
        $member->nepCaption=$request->nepCaption;
        $member->keywords=$request->keywords;
        $member->metaTag=$request->metaTag;
        $member->metaDescription=$request->metaDescription;
        $member->user_id=Auth::id();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->logo=$image;
                
        }

            else
    {
         
        return redirect('members');

    }


        $img=$request->file1;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->BOD_image=$image;
                
        }

            else
    {
         
        return redirect('members');

    }

         $img=$request->file2;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->MgmtTeam_image=$image;
                
        }

            else
    {
         
        return redirect('members');

    } 




        $member->save();

        return redirect('members');   

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $setting=Setting::all();
        $member=Members::find($id);
        //dd($about);
        return view('back.members.viewone',['member'=>$member,'row'=>$setting]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        //
        $setting=Setting::all();
        $member=Members::paginate(10);
        $result=Members::find($id);
        //dd($sl);
        return view('back.members.edit',['row'=>$setting,'member'=>$member,'result'=>$result]);


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //


        $member=Members::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->logo=$image;
            
            }

            else
            {
            
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->logo=$image;
            
            }

                
        }
        else
        {
            $member->logo=$request->h_image;

        }

//bod image

        $img=$request->file1;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->BOD_image=$image;
            
            }

            else
            {
            
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->BOD_image=$image;
            
            }

                
        }
        else
        {
            $member->BOD_image=$request->h_image1;

        }

//bod image end

//mgmt team image

        $img=$request->file2;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->MgmtTeam_image=$image;
            
            }

            else
            {
            
            $dest_path = "img/members/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(227, 300);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $member->MgmtTeam_image=$image;
            
            }

                
        }
        else
        {
            $member->MgmtTeam_image=$request->h_image2;

        }


        //mgmt team image end




        $member->finance_name=$request->finance;
        $member->address=$request->address;
        $member->contactno=$request->contactno;
        $member->email=$request->email;
        $member->introduction=$request->introduction;
        $member->BOD_name=$request->bod_name;
        $member->BODM_position=$request->position;
        $member->BODM_intro=$request->introduction;
        $member->MgmtTeam_name=$request->MgmtTeam_name;
        $member->MgmtTeam_position=$request->MgmtTeam_position;
        $member->MgmtTeam_intro=$request->MgmtTeam_intro;

        $member->nepFinance_name=$request->nepFinance_name;
        $member->nepAddress=$request->nepAddress;
        $member->nepIntroduction=$request->nepIntro;
        $member->nepBOD_name=$request->nepBOD_name;
        $member->nepBODM_position=$request->nepBODM_position;
        $member->nepBODM_intro=$request->nepBODM_intro;
        $member->nepMgmtTeam_name=$request->nepMgmtTeam_name;
        $member->nepMgmtTeam_position=$request->nepMgmtTeam_position;
        $member->nepMgmtTeam_intro=$request->nepMgmtTeam_intro;

        $member->caption=$request->caption;
        $member->nepCaption=$request->nepCaption;
        $member->keywords=$request->keywords;
        $member->metaTag=$request->metaTag;
        $member->metaDescription=$request->metaDescription;
        $member->user_id=Auth::id();
        $member->save();
        return redirect('viewMembers');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        $data=Members::find($id);
        if(!is_null($data->logo)) //image files
        {
            $file_path=$data->logo;
            if(file_exists($file_path))
                unlink($file_path);
        }

        $data->delete();
        
        return redirect('viewMembers');

    }


public function inactivate(Request $request, $id)
    {
        $member=Members::find($id);
        $member->user_id=Auth::id();
        $member->status=1;

        $member->save();
        return redirect('viewMembers'); 
    }


    public function activate(Request $request, $id)
    {
        $member=Members::find($id);
        $member->user_id=Auth::id();
        $member->status=0;
        //dd($slider);

        $member->save();
        return redirect('viewMembers'); 
    }

    public function inactive(Request $request, $id)
    {
        $member=Members::find($id);
        $member->user_id=Auth::id();
        $member->active=1;

        $member->save();
        return redirect('viewMembers'); 
    }


    public function active(Request $request, $id)
    {
        $member=Members::find($id);
        $member->user_id=Auth::id();
        $member->active=0;
        //dd($slider);

        $member->save();
        return redirect('viewMembers'); 
    }

}
