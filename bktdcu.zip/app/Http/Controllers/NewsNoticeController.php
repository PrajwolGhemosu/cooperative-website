<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\NewsNotice;
use App\Setting;
use Image; 
use auth;

class NewsNoticeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $newsnotice=new NewsNotice();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/newsnotice/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(400, 400);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $newsnotice->file=$image;
                
        }

            else
    {
        
    
        return redirect('newsnotice');

    }

        $newsnotice->title=$request->title;
        $newsnotice->description=$request->description;
        $newsnotice->nepTitle=$request->nepTitle;
        $newsnotice->nepDescription=$request->nepDescription;
        $newsnotice->type=$request->type;
        $newsnotice->status=0;
        $newsnotice->rank=1;
        $newsnotice->caption=$request->caption;
        $newsnotice->nepCaption=$request->nepCaption;
        $newsnotice->keywords=$request->keywords;
        $newsnotice->metaTag=$request->metaTag;
        $newsnotice->metaDesc=$request->metaDesc;
        $newsnotice->user_id=Auth::id();
        $newsnotice->save();
        return redirect('newsnotice');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $newsnotice=NewsNotice::paginate(10);
        $result=NewsNotice::find($id);
        //dd($sl);
        return view('back.newsnotice.edit',['newsnotice'=>$newsnotice,'row'=>$setting,'result'=>$result]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $newsnotice=NewsNotice::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/newsnotice/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(400, 400);
            $img->save(public_path($dest_path.$filename));

            $newsnotice->file = $dest_path.$filename;
            
            //$testimonial->imagefile=$image;
            
            }

            else
            {
            
            $dest_path = "img/testimonial/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(300, 300);
            $img->save(public_path($dest_path.$filename));

            $newsnotice->file = $dest_path.$filename;
            
            //$testimonial->imagefile=$image;
            
            }

                
        }
        else
        {
            $newsnotice->file=$request->image;

        }

        $newsnotice->title=$request->title;       
        $newsnotice->description=$request->description;

        $newsnotice->nepTitle=$request->nepTitle;
        $newsnotice->nepDescription=$request->nepDescription;
        $newsnotice->type=$request->type;
        $newsnotice->status=0;
        $newsnotice->rank=1;
        $newsnotice->caption=$request->caption;
        $newsnotice->nepCaption=$request->nepCaption;
        $newsnotice->keywords=$request->keywords;
        $newsnotice->metaTag=$request->metaTag;
        $newsnotice->metaDesc=$request->metaDesc;
        $newsnotice->user_id=Auth::id();
        $newsnotice->save();
        return redirect('newsnotice');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=NewsNotice::find($id);
        $data->delete();
        
        return redirect('newsnotice');
    }

    public function inactivate(Request $request, $id)
    {
        $newsnotice=NewsNotice::find($id);
        $newsnotice->user_id=Auth::id();
        $newsnotice->status=1;

        $newsnotice->save();
        return redirect('newsnotice'); 
    }


    public function activate(Request $request, $id)
    {
        $newsnotice=NewsNotice::find($id);
        $newsnotice->user_id=Auth::id();
        $newsnotice->status=0;
        //dd($testimonial);

        $newsnotice->save();
        return redirect('newsnotice'); 
    }
}
