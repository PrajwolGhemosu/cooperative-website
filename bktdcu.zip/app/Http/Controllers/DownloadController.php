<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use Auth;
use Input as Input;
use File;
use Image;
use App\Download;

class DownloadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $download=new Download();

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/download/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(690, 690);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $download->file=$image;
                
        }

            else
    {
        
    
        return redirect('download');

    }

        $download->title=$request->title;
        $download->type=$request->type;
        $download->nepTitle=$request->nepTitle;
        $download->status=0;
        $download->save();
        return redirect('download');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $download=Download::paginate(9);
        $result=Download::find($id);

        //dd($sl);
        return view('back.download.edit',['row'=>$setting,'download'=>$download,'result'=>$result]);
 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $download=Download::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/download/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(690, 690);
            $img->save(public_path($dest_path.$filename));

            $download->file = $dest_path.$filename;
            
            }

            else
            {
            
            $dest_path = "img/download/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(690, 690);
            $img->save(public_path($dest_path.$filename));

            $download->file = $dest_path.$filename;
            

            
            }

                
        }
        else
        {
            $download->file=$request->h_file;

        }

        $download->title=$request->title;
        $download->type=$request->type;
        $download->nepTitle=$request->nepTitle;
        $download->save();
        return redirect('viewDownload');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=Download::find($id);
        if(!is_null($data->file)) //image files
        {
            $file_path=$data->file;
            if(file_exists($file_path))
                unlink($file_path);
        }
        
        $data->delete();
        return redirect('viewDownload');

    }

    public function inactivate(Request $request, $id)
    {
        $download=Download::find($id);
        $download->status=1;

        $download->save();
        return redirect('viewDownload'); 
    }


    public function activate(Request $request, $id)
    {
        $download=Download::find($id);
        $download->status=0;
        //dd($download);

        $download->save();
        return redirect('viewDownload'); 
    }
}
