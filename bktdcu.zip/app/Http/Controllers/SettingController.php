<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use Auth;
use Input as Input;
use File;
use Image;  // for resize of image


class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $setting=Setting::find($id);
        //dd($setting);
        $setting->user_id=Auth::id();
        $setting->company=$request->company;
        $setting->address=$request->address;
        $setting->services=$request->services;
        $setting->nep_services=$request->nep_services;
        $setting->contact=$request->contact;
        $setting->nepCompany=$request->nepCompany;
        $setting->nepAddress=$request->nepAddress;
        $setting->nepContact=$request->nepContact;
        $setting->email=$request->email;
        $setting->google_map=$request->google_map;
        $setting->facebook=$request->facebook;
        $setting->youtube=$request->youtube;
        $setting->google_plus=$request->google_plus;
        $setting->twitter=$request->twitter;
        $setting->instagram=$request->instagram;
        $setting->caption=$request->caption;
        $setting->nepCaption=$request->nepCaption;
        $setting->keywords=$request->keywords;
        $setting->metaTag=$request->metaTag;
        $setting->metaDescription=$request->metaDescription;
        //$group->metaDesc(table_column)=$request->metaDesc(form feild);
        
        $logo=$request->file;
        $h_logo=$request->h_file;
        //newly added

        if(!is_null($logo))
        {
            $file_path= $request->logo_pic;
            if(file_exists($file_path))
            {
                unlink($file_path);
                $dest_path = "img/setting/";
                $filename =uniqid()."-".$logo->getClientOriginalName();
                
                //resize image
                $logo = Image::make($logo->getRealPath());
                $logo->resize(120, 120);
                $logo->save(public_path($dest_path.$filename));

                //$logo->move($dest_path,$filename);
                $image = $dest_path.$filename;
                $setting->logo=$image;
            }
            else
            {
                 $dest_path = "img/setting/";
                 $filename =uniqid()."-".$logo->getClientOriginalName();
                 //resize image
                 $logo = Image::make($logo->getRealPath());
                 $logo->resize(120, 120);
                 $logo->save(public_path($dest_path.$filename));
                 //$logo->move($dest_path,$filename);
                 $image = $dest_path.$filename;
                 $setting->logo=$image;
             }        
        }
        else
        {
            $setting->logo=$request->logo_pic;
            // if(Input::hasFile('file'))
            // {
            //     $file=Input::file('file');
            //     $img_path='img/setting/';
            //     $image=$file->getClientOriginalName();
            //     $file->move('img/setting',$image);
            //     $dest=$img_path.$image;
            //     $setting->logo=$dest;
            // }
        }

        if(!is_null($h_logo))
        {
            $file_path= $request->h_logo_pic;
            if(file_exists($file_path))
            {
                unlink($file_path);
                $dest_path = "img/setting/";
                $filename =uniqid()."-".$h_logo->getClientOriginalName();
                
                //resize image
                $h_logo = Image::make($h_logo->getRealPath());
                $h_logo->resize(600, 120);
                $h_logo->save(public_path($dest_path.$filename));

                //$logo->move($dest_path,$filename);
                $image = $dest_path.$filename;
                $setting->h_logo=$image;
            }
            else
            {
                 $dest_path = "img/setting/";
                 $filename =uniqid()."-".$h_logo->getClientOriginalName();
                 //resize image
                 $h_logo = Image::make($h_logo->getRealPath());
                 $h_logo->resize(600, 120);
                 $h_logo->save(public_path($dest_path.$filename));
                 //$logo->move($dest_path,$filename);
                 $image = $dest_path.$filename;
                 $setting->h_logo=$image;
             }        
        }
        else
        {
            $setting->h_logo=$request->h_logo_pic;
            // if(Input::hasFile('file'))
            // {
            //     $file=Input::file('file');
            //     $img_path='img/setting/';
            //     $image=$file->getClientOriginalName();
            //     $file->move('img/setting',$image);
            //     $dest=$img_path.$image;
            //     $setting->logo=$dest;
            // }
        }

        $setting->save();
        return redirect('setting');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function eng($id)
    {
        //
        $setting=Setting::find($id);
        //dd($setting);
        /*$setting->user_id=Auth::id();*/
        $setting->lan=1;

        $setting->save();
        return redirect('home');
    }

    public function nep($id)
    {
        //
        $setting=Setting::find($id);
        // dd($setting);
/*        $setting->user_id=Auth::id();
*/        $setting->lan=2;

        $setting->save();
        return redirect('home');
    }
}
