<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\About;
use File;
use Image;
use Auth;

class AboutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $about=new About();

        $about->title=$request->title;
        $about->description=$request->description;
        $about->nepTitle=$request->nepTitle;
        $about->nepDescription=$request->nepDescription;
        $about->caption=$request->caption;
        $about->nepCaption=$request->nepCaption;
        $about->nepCaption=0;
        $about->keywords=$request->keywords;
        $about->metaTag=$request->metaTag;
        $about->metaDesc=$request->metaDesc;

        $about->save();

        return redirect('D-about');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $setting=Setting::all();
        $about=About::find($id);
        //dd($about);
        return view('back.about.view',['data'=>$about,'row'=>$setting]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $about=About::find($id);
        //dd($about);
        return view('back.about.edit',['data'=>$about,'row'=>$setting,]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $about=About::find($id);
        $about->title=$request->title;
        $about->description=$request->description;
        $about->nepTitle=$request->nepTitle;
        $about->nepDescription=$request->nepDescription;
        $about->caption=$request->caption;
        $about->nepCaption=$request->nepCaption;
        $about->keywords=$request->keywords;
        $about->metaTag=$request->metaTag;
        $about->metaDesc=$request->metaDesc;

        $about->save();

        return redirect('D-about');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=About::find($id);
        $data->delete();
        
        return redirect('D-about');
    }

    public function inactivate(Request $request, $id)
    {
        $newsnotice=NewsNotice::find($id);
        $newsnotice->user_id=Auth::id();
        $newsnotice->status=0;

        $newsnotice->save();
        return redirect('newsnotice'); 
    }


    public function activate(Request $request, $id)
    {
        $newsnotice=NewsNotice::find($id);
        $newsnotice->user_id=Auth::id();
        $newsnotice->status=1;
        //dd($testimonial);

        $newsnotice->save();
        return redirect('newsnotice'); 
    }
}
