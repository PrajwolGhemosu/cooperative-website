<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;
use Auth;
use App\Setting;
use Input as Input;
use File;
use Image;// for resize of image

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $service=new Service();

        $service->serviceTopics=$request->topic;
        $service->serviceDescription=$request->description;
        $service->nepTopics=$request->nepTopics;
        $service->nepDescription=$request->nepDescription;
        $service->status=0;
        $service->caption=$request->caption;
        $service->nepCaption=$request->nepCaption;
        $service->keywords=$request->keywords;
        $service->metaTag=$request->metaTag;
        $service->metaDescription=$request->metaDescription;
        $service->user_id=Auth::id();

        
        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $dest_path = "img/service/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(800, 500);
            $img->save(public_path($dest_path.$filename));

            $image = $dest_path.$filename;
            
            $service->image=$image;
                
        }

            else
    {
        
    
        return redirect('service');

    }




        $service->save();

        return redirect('service');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $setting=Setting::all();
        $service=Service::find($id);
        //dd($about);
        return view('back.service.viewone',['service'=>$service,'row'=>$setting]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $setting=Setting::all();
        $service=Service::paginate(10);
        $result=Service::find($id);
        //dd($sl);
        return view('back.service.edit',['row'=>$setting,'service'=>$service,'result'=>$result]);


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $service=Service::find($id);

        $img=$request->file;
        //newly added

        if(!is_null($img))
        { 
            $file_path= $request->image;
            
            if(file_exists($file_path))
            {
            
            unlink($file_path);
            $dest_path = "img/service/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(800, 500);
            $img->save(public_path($dest_path.$filename));

            $service->image= $dest_path.$filename;
            
           /* $service->image=$image;*/
            
            }

            else
            {
            
            $dest_path = "img/service/";
            $filename =uniqid()."-".$img->getClientOriginalName();
            
            //resize image
            $img = Image::make($img->getRealPath());
            $img->resize(800, 500);
            $img->save(public_path($dest_path.$filename));

            $service->image = $dest_path.$filename;
            
            /*$service->image=$image;*/
            
            }

                
        }
        else
        {
            $service->image=$request->h_image;

        }

        $service->serviceTopics=$request->topic;
        $service->serviceDescription=$request->description;
        $service->nepTopics=$request->nepTopics;
        $service->nepDescription=$request->nepDescription;    
        $service->caption=$request->caption;
        $service->nepCaption=$request->nepCaption;
        $service->nepCaption=0;
        $service->keywords=$request->keywords;
        $service->metaTag=$request->metaTag;
        $service->metaDescription=$request->metaDescription;


        $service->save();
        return redirect('viewService');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=Service::find($id);
        if(!is_null($data->image)) //image files
        {
            $file_path=$data->image;
            if(file_exists($file_path))
                unlink($file_path);
        }

        $data->delete();
        
        return redirect('service');
    }



public function inactivate(Request $request, $id)
    {
        $service=Service::find($id);
        $service->user_id=Auth::id();
        $service->status=1;

        $service->save();
        return redirect('viewService'); 
    }


    public function activate(Request $request, $id)
    {
        $service=Service::find($id);
        $service->user_id=Auth::id();
        $service->status=0;
        //dd($slider);

        $service->save();
        return redirect('viewService'); 
    }

}
