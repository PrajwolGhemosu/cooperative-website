<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MemberUser extends Model
{
    //
}
