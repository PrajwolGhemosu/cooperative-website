<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('members', function (Blueprint $table) {
            $table->increments('id')
            $table->string('finance_name')->nullable();
            $table->string('address')->nullable();
            $table->string('contactno')->nullable();
            $table->string('email')->nullable();
            $table->string('introduction')->nullable();
            $table->string('logo')->nullable();
            $table->string('BODM_intro')->nullable();
            $table->string('BOD_name')->nullable();
            $table->string('BODM_position')->nullable();
            $table->string('BOD_image')->nullable();
            $table->string('MgmtTeam_image')->nullable();
            $table->string('MgmtTeam_intro')->nullable();
            $table->string('MgmtTeam_name')->nullable();
            $table->string('MgmtTeam_position')->nullable();

            $table->string('nepFinance_name')->nullable();
            $table->string('nepAddress')->nullable();
            $table->string('nepIntroduction')->nullable();
            $table->string('nepBODM_intro')->nullable();
            $table->string('nepBOD_name')->nullable();
            $table->string('nepBODM_position')->nullable();
            $table->string('nepMgmtTeam_intro')->nullable();
            $table->string('nepMgmtTeam_name')->nullable();
            $table->string('nepMgmtTeam_position')->nullable();
           
            $table->integer('status')->nullable();
            $table->integer('active')->nullable();
            $table->string('caption')->nullable();
            $table->string('nepCaption')->nullable();
            $table->string('keywords')->nullable();
            $table->string('metaTag')->nullable();
            $table->string('metaDescription')->nullable();

            $table->integer('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('members');
    }
}
