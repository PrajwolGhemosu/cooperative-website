<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNewsNoticesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('news_notices', function (Blueprint $table) {
            $table->increments('id');
            $table->string('file');
            $table->string('title');
            $table->string('description')->nullable();
            $table->string('nepTitle')->nullable();
            $table->string('nepDescription')->nullable();
            $table->string('type')->nullable();
            $table->string('status')->nullable();
            $table->string('rank')->nullable();
            $table->string('caption')->nullable();
            $table->string('nepCaption')->nullable();
            $table->string('keywords')->nullable();
            $table->string('metaTag')->nullable();
            $table->string('metaDesc')->nullable();
            $table->integer('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('news_notices');
    }
}
